<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SendController;

//Route::get('restaurant', function () {
//  return view('../partials/shortcodes/cart-list/index');
//});

//Route::post('/send', [SendController::class, 'sendForm'])->name('send');
Theme::routes();