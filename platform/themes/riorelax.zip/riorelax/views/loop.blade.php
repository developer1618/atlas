@include(Theme::getThemeNamespace() . '::views.templates.posts')
