<div class="booking-area homepage p-relative">
    <div class="container">
        {!! Theme::partial('hotel.forms.form', ['style' => 2, 'availableForBooking' => false]) !!}
    </div>
</div>
