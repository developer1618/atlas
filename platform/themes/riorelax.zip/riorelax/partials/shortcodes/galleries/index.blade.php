<section class="section pb-100">
    <section class="profile fix pt-60">
        <div class="container-xxl">
            {!! Theme::partial('gallery.galleries', ['galleries' => $galleries]) !!}
        </div>
    </section>
</section>
