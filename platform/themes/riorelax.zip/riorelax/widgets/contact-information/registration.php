<?php

require_once __DIR__ . '/contact-information.php';

register_widget(ContactInformationMenuWidget::class);
