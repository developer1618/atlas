<?php

require_once __DIR__ . '/blog-posts.php';

register_widget(BlogPostsWidget::class);
