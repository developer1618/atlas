<?php

require_once __DIR__ . '/blog-socials.php';

register_widget(BlogSocialsWidget::class);
