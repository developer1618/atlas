<div class="form-group">
    <label class="control-label">{{ __('Title') }}</label>
    <input type="text" name="title" value="{{ $config['title'] }}" class="form-control" placeholder="{{ __('Title') }}">
</div>

