<?php

require_once __DIR__ . '/newsletter-subscribe.php';

register_widget(NewsletterWidget::class);
