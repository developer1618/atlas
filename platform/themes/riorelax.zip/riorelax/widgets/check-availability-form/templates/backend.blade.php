<section>
    <div class="form-group">
        <label for="widget-booking-form-title">{{ __('Title') }}</label>
        <input type="text" id="widget-booking-form-title" class="form-control" name="title" value="{{ $config['title'] }}">
    </div>
</section>
