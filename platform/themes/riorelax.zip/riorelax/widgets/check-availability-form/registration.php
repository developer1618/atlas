<?php

require_once __DIR__ . '/check-availability-form.php';

register_widget(CheckAvailabilityForm::class);
