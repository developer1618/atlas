<?php

require_once __DIR__ . '/blog-search.php';

register_widget(BlogSearchWidget::class);
