<div class="form-group mb-3">
    <label for="widget-room-contact-form-title">{{ __('Title') }}</label>
    <input type="text" id="widget-room-contact-form-title" class="form-control" name="title" value="{{ $config['title'] }}">
</div>

<div class="form-group mb-3">
    <label for="widget-room-contact-form-button_label">{{ __('Phone') }}</label>
    <input type="number" id="widget-room-contact-form-phone" class="form-control" name="phone" value="{{ $config['phone'] }}">
</div>
