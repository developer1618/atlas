<?php

require_once __DIR__ . '/room-contact.php';

register_widget(RoomContactWidget::class);
